from flask import Flask, render_template, request, redirect, make_response
import sqlite3
import jwt
from datetime import datetime, timedelta, timezone
import os

app = Flask(__name__)

SECRET_KEY = os.environ.get("SECRET_KEY", "dev_secret")
TOKEN_EXPIRY_MINUTES = 30
DB = "database.db"


def get_db():
    return sqlite3.connect(DB)


# ---------- Initialize Database ----------
def init_db():
    conn = get_db()
    c = conn.cursor()

    c.execute('''CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password TEXT,
        role TEXT
    )''')

    # ensure at least one admin exists
    admin = c.execute("SELECT * FROM users WHERE role='admin'").fetchone()
    if not admin:
        c.execute("INSERT INTO users(username,password,role) VALUES('admin','admin123','admin')")

    conn.commit()
    conn.close()

init_db()


# ---------- JWT Verification ----------
def verify_token(token):
    try:
        return jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
    except:
        return None


# ---------- Root Route ----------
@app.route("/")
def home():
    token = request.cookies.get("auth_token")
    data = verify_token(token) if token else None
    if data:
        return redirect("/dashboard")
    return redirect("/login")


# ---------- Register ----------
@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        role = request.form["role"]

        conn = get_db()
        try:
            conn.execute(
                "INSERT INTO users(username,password,role) VALUES(?,?,?)",
                (username, password, role)
            )
            conn.commit()
        except sqlite3.IntegrityError:
            return "Username already exists"
        finally:
            conn.close()

        return redirect("/login")

    return render_template("register.html")


# ---------- Login ----------
@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        conn = get_db()
        user = conn.execute(
            "SELECT username, role FROM users WHERE username=? AND password=?",
            (username, password)
        ).fetchone()
        conn.close()

        if user:
            payload = {
                "user": user[0],
                "role": user[1],
                "exp": datetime.now(timezone.utc) + timedelta(minutes=TOKEN_EXPIRY_MINUTES)
            }

            token = jwt.encode(payload, SECRET_KEY, algorithm="HS256")

            resp = make_response(redirect("/dashboard"))
            resp.set_cookie("auth_token", token)
            return resp

        return "Invalid credentials"

    return render_template("login.html")


# ---------- Dashboard ----------
@app.route("/dashboard")
def dashboard():
    token = request.cookies.get("auth_token")
    data = verify_token(token) if token else None
    if not data:
        return redirect("/login")

    return render_template("dashboard.html",
                           user=data["user"],
                           role=data["role"])


# ---------- Admin Panel ----------
@app.route("/admin")
def admin():
    token = request.cookies.get("auth_token")
    data = verify_token(token) if token else None

    if not data or data["role"] != "admin":
        return "Access denied"

    conn = get_db()
    users = conn.execute("SELECT id, username, role FROM users").fetchall()
    conn.close()

    return render_template("admin.html", users=users)


# ---------- Delete User ----------
@app.route("/delete/<int:user_id>")
def delete_user(user_id):
    token = request.cookies.get("auth_token")
    data = verify_token(token) if token else None

    if not data or data["role"] != "admin":
        return "Access denied"

    conn = get_db()
    conn.execute("DELETE FROM users WHERE id=?", (user_id,))
    conn.commit()
    conn.close()

    init_db()  # ensure admin still exists

    return redirect("/admin")


# ---------- Password Reset ----------
@app.route("/reset", methods=["GET","POST"])
def reset():
    if request.method == "POST":
        username = request.form["username"]
        new_password = request.form["new_password"]

        conn = get_db()
        conn.execute("UPDATE users SET password=? WHERE username=?",
                     (new_password, username))
        conn.commit()
        conn.close()

        return redirect("/login")

    return render_template("reset.html")


# ---------- Logout ----------
@app.route("/logout")
def logout():
    resp = make_response(redirect("/login"))
    resp.set_cookie("auth_token", "", expires=0)
    return resp


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port)